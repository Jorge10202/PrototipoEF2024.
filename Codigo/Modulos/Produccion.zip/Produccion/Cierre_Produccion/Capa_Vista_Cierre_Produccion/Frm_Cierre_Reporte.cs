﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capa_Vista_Cierre_Produccion
{
    public partial class Frm_Cierre_Reporte : Form
    {
        public Frm_Cierre_Reporte()
        {
            InitializeComponent();
        }
    }
}
